# cuTEST

Testing framework to use for C++ classes

Note: This requires building with c++11 flags (or later... using function pointers).
