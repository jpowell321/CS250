/*
Edit this file
*/

#include "StudentCode.hpp"

/*
Using StudentCode.cpp for reference,
implement the Queue's POP function.
This queue is a linked list type of structure;
you will have to directly modify the private
member variables of the Queue class in the
.hpp file.
*/
bool Queue::Pop()
{
	return false;
}
