# CPP-Utilities
Command line utils for use in multiple programs

* Logger - Write to an external log file and the console. Output and errors, logging levels.
* Menu - basic console menu options, as well as cross-platform pause and clear screen.
* Strings - string utils, such as conversion between data-types, and toupper/tolower wrapper.
