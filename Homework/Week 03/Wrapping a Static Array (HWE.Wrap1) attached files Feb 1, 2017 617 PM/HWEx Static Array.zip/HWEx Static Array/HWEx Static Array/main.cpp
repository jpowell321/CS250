#include <iostream>
using namespace std;

#include "Tester_SmartStaticArray.hpp"

int main()
{
    Tester_SmartStaticArray::Start();

    return 0;
}
