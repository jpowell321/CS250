#include "SmartStaticArray.hpp"

SmartStaticArray::SmartStaticArray()
{
	m_itemCount = 0;
}

bool SmartStaticArray::Push( const string& newItem )
{
	return false; // temp
}


bool SmartStaticArray::Insert( int index, const string& newItem )
{
	return false; // temp
}


bool SmartStaticArray::Extend( const SmartStaticArray& other )
{
	return false; // temp
}


bool SmartStaticArray::Pop()
{
	return false; // temp
}


bool SmartStaticArray::Remove( int index )
{
	return false; // temp
}


string SmartStaticArray::Get( int index ) const
{
	return "temp"; // temp
}


int SmartStaticArray::Size() const
{
	return -1; // temp
}


bool SmartStaticArray::IsFull() const
{
	return false; // temp
}

bool SmartStaticArray::IsEmpty() const
{
	return false; // temp
}


string SmartStaticArray::operator[]( int index )
{
	return "temp"; // temp
}


SmartStaticArray& SmartStaticArray::operator=( const SmartStaticArray& other )
{
    SmartStaticArray blorp; // temp
    return blorp; // temp
}

bool SmartStaticArray::operator==( const SmartStaticArray& other )
{
	return false; // temp
}
